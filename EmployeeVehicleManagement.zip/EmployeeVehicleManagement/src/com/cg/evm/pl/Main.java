package com.cg.evm.pl;

import java.security.Provider.Service;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.evm.dto.Employee;
import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;
import com.cg.evm.service.EmployeeService;
import com.cg.evm.service.EmployeeServiceImpl;
import com.cg.evm.service.VehicleService;
import com.cg.evm.service.VehicleServiceImpl;

public class Main {
public static void main(String[] args) {
	
		Scanner sc= new Scanner(System.in);
		String name;
		double salary;
		String date,loc;
		VehicleService vehService= new VehicleServiceImpl();
		System.out.println("Welcome to Vehicle Registration System..");
		System.out.println("Select option ");
		System.out.println("1. Add Employee Details ");
		System.out.println("2.Add Vehicle details ");
		System.out.println("3.Display Vehicle Details ");
		System.out.println("4. Display List of Employees ");
		System.out.println("5.Display list of 2 wheeler vehicles.");
		int choice= sc.nextInt();
		switch(choice){
	
		case 1:
	
		System.out.println("Enter name : ");
		name=sc.next();
		System.out.println("Enter Salary :");
		salary= sc.nextDouble();		
		System.out.println("Enter Location ");
		loc= sc.next();
		System.out.println("Enter Joining Date (dd-MMM-yyyy) :");
		date=sc.next();
		DateTimeFormatter formatter=
				DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate joindate= LocalDate.parse(date, formatter);
		Employee empl= new Employee();
		empl.setName(name);
		empl.setLocation(loc);
		empl.setSalary(salary);
		empl.setJoindate(joindate);
		EmployeeService service= new EmployeeServiceImpl();
		boolean res= service.validateEmployee(empl);
		if(res==true){
				int id= service.addEmployeeDetails(empl);
					System.out.println("Employee id :"+ id);
		}
		else
			System.out.println("Invalid details entered....");
		
		case 2:
			String type,number;
			int empid;
			
			System.out.println("Enter empid: ");
			empid=sc.nextInt();
			System.out.println("Enter type of vehicle : ");
			type=sc.next();
			System.out.println("Enter Vehicle Number" );
			number= sc.next();
			VehicleDetails vehicle= new VehicleDetails();
			vehicle.setVehicleNumber(number);
			vehicle.setEmpid(empid);
			vehicle.setVehicleType(type);
			try {
				int code= vehService.addVehicleDetails(vehicle);
				System.out.println("vehicle Details added :"+ code);
			} catch (VehicleException e) {
				System.out.println(e.getMessage());
			}
		
		case 3:
					
			System.out.println("Enter empid ");
			String vehicleType = sc.next();
			try {
				List<VehicleDetails> list= 
						vehService.getVehicleDetails(vehicleType);
				if(list.size()==0)
					System.out.println("No Vehicle Record found for you ...");
				else{
				for(VehicleDetails vh : list){
					System.out.print(vh.getVehicleCode()+" ");
					System.out.print(vh.getVehicleNumber()+" ");
					System.out.println(vh.getVehicleType()+"  ");
				}
				}
				
				
			} catch (VehicleException e) {
				System.out.println(e.getMessage());
			}
		
		
		case 4:
			
		System.out.println("Enter location");
		loc=sc.next();
			EmployeeService s =new EmployeeServiceImpl();
			List<Employee> list=
					s.getEmployee(loc);
			if(list==null)
				System.out.println("No Employee Record found for you...");
			else{
				for(Employee emp: list){
					System.out.println(emp.getEmpid()+" ");
					System.out.println(emp.getLocation()+ " ");
					System.out.println(emp.getJoindate()+" ");
					System.out.println(emp.getSalary()+" ");
				}
			}
		
			break;
		case 5:
			try {		
					System.out.println("Enter Vehicle_Type");
					String vehicle_type=sc.next();
			List<VehicleDetails> list1;
			
				list1 = vehService.getVehicleDetails(vehicle_type);
			
					if(list1.size()==0)
						System.out.println("No vehicle Record found for you...");
					else
						for(VehicleDetails vh: list1){
							System.out.println(vh.getVehicleCode()+" ");
							System.out.println(vh.getVehicleNumber()+" ");
						}
			}
		 catch (VehicleException e) {
			
			
		}
				
		
}
}
}














