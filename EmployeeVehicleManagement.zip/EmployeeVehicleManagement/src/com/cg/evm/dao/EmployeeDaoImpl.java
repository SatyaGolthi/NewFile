package com.cg.evm.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.evm.dto.Employee;
import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;
import com.cg.evm.util.DatabaseConnection;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public int addEmployeeDetails(Employee emp) {
		int empid=0;
		Connection con=DatabaseConnection.getConnection();
		String sql= "insert into "
				+ " employees(empid, empname,salary,location,join_date) "
				+ "values(empidSeq.nextval,?,?,?,?)";
		
			try {
				PreparedStatement ps= con.prepareStatement(sql);
				ps.setString(1, emp.getName());
				ps.setDouble(2, emp.getSalary());
				ps.setString(3,emp.getLocation());
				Date sqlDate= Date.valueOf(emp.getJoindate());
				ps.setDate(4, sqlDate);
				int rows= ps.executeUpdate();
				String query= "select empidseq.currval from dual";
				Statement s= con.createStatement();
				ResultSet rs= s.executeQuery(query);
					if(rs.next())
					{	empid=rs.getInt(1);
						return empid;
					}
					} catch (SQLException e) {
			System.out.println(e.getMessage());
			}
			return 0;
	}
	@Override
	public List<Employee> getEmployee(String loc)  {
			
		List<Employee> list= new ArrayList<Employee>();
		
		String sql="select empid,empname,salary,location,join_date "
				+ " from employees "
				+ "  where location=?";
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1, loc);
			
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				Employee emp= new Employee();
				int empid=rs.getInt("empid");
				String name=rs.getString("empname");
				double sal= rs.getDouble("salary");
				String location = rs.getString("location");
				LocalDate joindate = rs.getDate("join_date").toLocalDate();
				
				
				emp.setEmpid(empid);
				emp.setName(name);
				emp.setSalary(sal);
				emp.setLocation(location);
				emp.setJoindate(joindate);
				
				list.add(emp);
		}
		} catch (SQLException e) 
		{
	
		System.out.println(e.getMessage());
		}
	
		return list;

}

}




