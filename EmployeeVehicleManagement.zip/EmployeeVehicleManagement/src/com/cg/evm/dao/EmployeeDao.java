package com.cg.evm.dao;

import java.util.List;

import com.cg.evm.dto.Employee;

public interface EmployeeDao {
		public int addEmployeeDetails(Employee emp);
		List<Employee> getEmployee( String loc);
}
