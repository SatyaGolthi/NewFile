package com.cg.evm.service;

import java.util.List;

import com.cg.evm.dto.Employee;

public interface EmployeeService {
	public int addEmployeeDetails(Employee emp);
	public boolean validateEmployee(Employee emp);
	List<Employee> getEmployee( String loc);
	}

