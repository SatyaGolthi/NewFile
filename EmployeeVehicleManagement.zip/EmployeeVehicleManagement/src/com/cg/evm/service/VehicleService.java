package com.cg.evm.service;

import java.util.List;

import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;

public interface VehicleService {
	
	public int addVehicleDetails(VehicleDetails vehicle) throws VehicleException;

	public List<VehicleDetails> getVehicleDetails(String vehicle_type) throws VehicleException;

}
