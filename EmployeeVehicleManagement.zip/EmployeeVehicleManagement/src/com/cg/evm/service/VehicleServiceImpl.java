package com.cg.evm.service;

import java.util.List;

import com.cg.evm.dao.VehicleDao;
import com.cg.evm.dao.VehicleDaoImpl;
import com.cg.evm.dto.VehicleDetails;
import com.cg.evm.exception.VehicleException;

public class VehicleServiceImpl implements VehicleService{

	VehicleDao dao;
	public VehicleServiceImpl(){
		dao= new VehicleDaoImpl(); 
	}
	@Override
	public int addVehicleDetails(VehicleDetails vehicle) throws VehicleException {
		int code= dao.addVehicleDetails(vehicle);
		return code;
	}
	
	@Override
	public List<VehicleDetails> getVehicleDetails(String vehicle_type)
			throws VehicleException
			{
		      return dao.getVehicleDetails(vehicle_type);
	     }

	

}
