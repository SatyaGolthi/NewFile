package com.cg.evm.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.evm.dao.EmployeeDao;
import com.cg.evm.dao.EmployeeDaoImpl;
import com.cg.evm.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao;
	public EmployeeServiceImpl() {
		dao= new EmployeeDaoImpl();
	}
	public int addEmployeeDetails(Employee emp) {
		int id= dao.addEmployeeDetails(emp);
		return id;
	}
	public boolean validateEmployee(Employee emp) {
			//name should start with Upper case followed by lower case 
			Pattern pattern= Pattern.compile("[A-Z][a-z]{5,15}");
			Matcher matcher= pattern.matcher(emp.getName());
			if(matcher.matches())
			{
				if(emp.getSalary()>0){
					String loc= emp.getLocation();
					if(loc.equals("Pune") || loc.equals("Chennai"))
					return true;
					else 
					return false;
				}
				else
				return false;
			}
			else 
				return false;
	
	}
	@Override
	public List<Employee> getEmployee(String loc) {
		// TODO Auto-generated method stub
		return dao.getEmployee(loc);
	}
	

}
