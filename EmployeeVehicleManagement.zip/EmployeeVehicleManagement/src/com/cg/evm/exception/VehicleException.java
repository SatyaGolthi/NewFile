package com.cg.evm.exception;

public class VehicleException extends Exception{

	public VehicleException() {
		// TODO Auto-generated constructor stub
	}
	public VehicleException(String msg){
		super(msg);
	}
}
